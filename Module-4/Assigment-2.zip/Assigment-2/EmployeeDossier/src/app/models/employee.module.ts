export interface IEmployee {
    employeeId:number;
    firstName:string;
    lastName:string;
    salary:number;
    dob:Date;
    email:string;
}
