import { FormatSalaryPipe } from './format-salary.pipe';

describe('FormatSalaryPipe', () => {
  it('create an instance', () => {
    const pipe = new FormatSalaryPipe();
    expect(pipe).toBeTruthy();
  });
});
